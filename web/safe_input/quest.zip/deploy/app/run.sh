#!/bin/bash
export FLAG=DH{fake_flag}
python3 app.py