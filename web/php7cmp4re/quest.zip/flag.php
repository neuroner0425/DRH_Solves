<?php
    $flag = 'flag{**Sample**}'
?> 